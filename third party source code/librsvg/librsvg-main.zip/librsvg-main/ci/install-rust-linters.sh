#!/bin/bash

# IMPORTANT: See
# https://gnome.pages.gitlab.gnome.org/librsvg/devel-docs/ci.html#container-image-version

source ./ci/env.sh

set -eu
export CARGO_HOME='/usr/local/cargo'

rustup component add clippy
rustup component add rustfmt
cargo install --version ^1.0 gitlab_clippy
cargo install --force --locked cargo-deny
cargo install --force --locked rumdl --version 0.1.11
# cargo install --force cargo-outdated
