# build-win64-mxe

libvips and its dependencies cross-compiled for all supported Windows architectures (`x86_64`,
`i686` and `aarch64`).

Uses [MXE](https://github.com/mxe/mxe) as base environment. A custom plugin based upon the
[llvm-mingw](https://github.com/mstorsjo/llvm-mingw) repository is used to swap GCC and binutils
with Clang and other LLVM-based tools.

## Creating a zipball

Most people will not need to do this; proceed with caution.

Run the top-level [build script](build.sh) with the `--help` parameter for help.

## libvips-web dependencies

| Dependency      | Version    | Used under the terms of                                      |
|-----------------|------------|--------------------------------------------------------------|
| [aom]           | 3.14.1     | BSD 2-Clause + [Alliance for Open Media Patent License 1.0]  |
| [cairo]         | 1.18.4     | Mozilla Public License 2.0                                   |
| [cgif]          | 0.5.3      | MIT License                                                  |
| [expat]         | 2.8.2      | MIT License                                                  |
| [fontconfig]    | 2.18.1     | [fontconfig License] (BSD-like)                              |
| [freetype]      | 2.14.3     | [freetype License] (BSD-like)                                |
| [fribidi]       | 1.0.16     | LGPLv3                                                       |
| [glib]          | 2.89.1     | LGPLv3                                                       |
| [harfbuzz]      | 14.2.1     | MIT License                                                  |
| [highway]       | 1.4.0      | BSD 3-Clause                                                 |
| [lcms]          | 2.19.1     | MIT License                                                  |
| [libarchive]    | 3.8.8      | BSD 2-Clause                                                 |
| [libexif]       | 0.6.26     | LGPLv3                                                       |
| [libffi]        | 3.6.0      | MIT License                                                  |
| [libheif]       | 1.23.1     | LGPLv3                                                       |
| [libimagequant] | 2.4.1[^1]  | BSD 2-Clause                                                 |
| [libpng]        | 1.6.58     | [libpng License version 2]                                   |
| [librsvg]       | 2.62.90    | LGPLv3                                                       |
| [libtiff]       | 4.7.2      | [libtiff License] (BSD-like)                                 |
| [libultrahdr]   | [1acdbed]  | MIT License                                                  |
| [libvips]       | 8.18.4     | LGPLv3                                                       |
| [libwebp]       | 1.6.0      | New BSD License                                              |
| [libxml2]       | 2.15.3     | MIT License                                                  |
| [mozjpeg]       | [0826579]  | [zlib License, IJG License, BSD 3-Clause]                    |
| [pango]         | 1.58.0     | LGPLv3                                                       |
| [pixman]        | 0.46.4     | MIT License                                                  |
| [proxy-libintl] | 0.5        | LGPLv3                                                       |
| [zlib-ng]       | 2.3.3      | [zlib-ng License]                                            |

[^1]: [A fork](https://github.com/lovell/libimagequant) of the BSD 2-Clause licensed libimagequant v2.4.1 is used.

[1acdbed]: https://github.com/google/libultrahdr/commit/1acdbed8c712e6923ebf9de4e7c8d8dda06509e9
[0826579]: https://github.com/mozilla/mozjpeg/commit/08265790774cd0714832c9e675522acbe5581437

[aom]: https://aomedia.googlesource.com/aom/
[Alliance for Open Media Patent License 1.0]: https://aomedia.org/license/patent-license/
[cairo]: https://gitlab.freedesktop.org/cairo/cairo
[cgif]: https://github.com/dloebl/cgif
[expat]: https://github.com/libexpat/libexpat
[fontconfig]: https://gitlab.freedesktop.org/fontconfig/fontconfig
[fontconfig License]: https://gitlab.freedesktop.org/fontconfig/fontconfig/blob/main/COPYING
[freetype]: https://gitlab.freedesktop.org/freetype/freetype
[freetype License]: https://gitlab.freedesktop.org/freetype/freetype/blob/master/docs/FTL.TXT
[fribidi]: https://github.com/fribidi/fribidi
[glib]: https://gitlab.gnome.org/GNOME/glib
[harfbuzz]: https://github.com/harfbuzz/harfbuzz
[highway]: https://github.com/google/highway
[lcms]: https://github.com/mm2/Little-CMS
[libarchive]: https://github.com/libarchive/libarchive
[libexif]: https://github.com/libexif/libexif
[libffi]: https://github.com/libffi/libffi
[libheif]: https://github.com/strukturag/libheif
[libimagequant]: https://github.com/lovell/libimagequant
[libpng]: https://github.com/pnggroup/libpng
[libpng License version 2]: https://github.com/pnggroup/libpng/blob/master/LICENSE
[librsvg]: https://gitlab.gnome.org/GNOME/librsvg
[libtiff]: https://gitlab.com/libtiff/libtiff
[libtiff License]: https://gitlab.com/libtiff/libtiff/blob/master/LICENSE.md
[libultrahdr]: https://github.com/google/libultrahdr
[libvips]: https://github.com/libvips/libvips
[libwebp]: https://github.com/webmproject/libwebp
[libxml2]: https://gitlab.gnome.org/GNOME/libxml2
[mozjpeg]: https://github.com/mozilla/mozjpeg
[zlib License, IJG License, BSD 3-Clause]: https://github.com/mozilla/mozjpeg/blob/master/LICENSE.md
[pango]: https://gitlab.gnome.org/GNOME/pango
[pixman]: https://gitlab.freedesktop.org/pixman/pixman
[proxy-libintl]: https://github.com/frida/proxy-libintl
[zlib-ng]: https://github.com/zlib-ng/zlib-ng
[zlib-ng License]: https://github.com/zlib-ng/zlib-ng/blob/develop/LICENSE.md

## libvips-all dependencies

Same as libvips-web + these extra dependencies:

| Dependency      | Version    | Used under the terms of                                      |
|-----------------|------------|--------------------------------------------------------------|
| [brotli]        | 1.2.0      | MIT License                                                  |
| [cfitsio]       | 4.6.4      | BSD-like                                                     |
| [fftw]          | 3.3.11     | GPLv2                                                        |
| [imagemagick]   | 7.1.2-26   | [ImageMagick License] (Apache-2.0-like)                      |
| [imath]         | 3.2.2      | BSD 3-Clause                                                 |
| [libdicom]      | 1.3.0      | MIT License                                                  |
| [libjxl]        | 0.12.0     | BSD 3-Clause                                                 |
| [libraw]        | 0.22.1     | LGPL-2.1-only                                                |
| [matio]         | 1.5.30     | BSD 2-Clause                                                 |
| [nifticlib]     | 3.0.1      | Public domain                                                |
| [openexr]       | 3.1.13     | BSD 3-Clause                                                 |
| [openjpeg]      | 2.5.4      | BSD 2-Clause                                                 |
| [openslide]     | 4.0.1      | LGPL-2.1-only                                                |
| [poppler]       | 26.07.0    | GPLv2                                                        |
| [sqlite]        | 3.53.2     | Public domain                                                |
| [zstd]          | 1.5.7      | BSD 3-Clause                                                 |

[brotli]: https://github.com/google/brotli
[cfitsio]: https://github.com/HEASARC/cfitsio
[fftw]: https://github.com/FFTW/fftw3
[imagemagick]: https://github.com/ImageMagick/ImageMagick
[ImageMagick License]: https://github.com/ImageMagick/ImageMagick/blob/main/LICENSE
[imath]: https://github.com/AcademySoftwareFoundation/Imath
[libdicom]: https://github.com/ImagingDataCommons/libdicom
[libjxl]: https://github.com/libjxl/libjxl
[libraw]: https://github.com/LibRaw/LibRaw
[matio]: https://github.com/tbeu/matio
[nifticlib]: https://github.com/NIFTI-Imaging/nifti_clib
[openexr]: https://github.com/AcademySoftwareFoundation/openexr
[openjpeg]: https://github.com/uclouvain/openjpeg
[openslide]: https://github.com/openslide/openslide
[poppler]: https://gitlab.freedesktop.org/poppler/poppler
[sqlite]: https://sqlite.org/
[zstd]: https://github.com/facebook/zstd

## libjpeg-turbo

libvips does not use any of MozJPEG's improvements by default unless explicitly set,
yet one can still choose to build the above variants with [libjpeg-turbo] instead of
[MozJPEG][mozjpeg]. This can be accomplished with the `--with-jpeg-turbo` argument.
For example:

```bash
./build.sh --with-jpeg-turbo
```

In that case, the following version of libjpeg-turbo is built:

| Dependency      | Version    | Used under the terms of                                      |
|-----------------|------------|--------------------------------------------------------------|
| [libjpeg-turbo] | 3.2.0      | [zlib License, IJG License]                                  |

[libjpeg-turbo]: https://github.com/libjpeg-turbo/libjpeg-turbo
[zlib License, IJG License]: https://github.com/libjpeg-turbo/libjpeg-turbo/blob/main/LICENSE.md

## jpegli

[jpegli] is an improved JPEG encoder and decoder implementation, fully compatible with
the API/ABI of libjpeg62. It leverages many of the insights from related projects like
[guetzli](https://github.com/google/guetzli), [butteraugli](
https://github.com/google/butteraugli), and [JPEG XL][libjxl] to achieve a higher
quality-per-byte for JPEG images. To enable this, use the `--with-jpegli` argument when
building. For example:

```bash
./build.sh --with-jpegli
```

In that case, the following version of jpegli is built:

| Dependency      | Version    | Used under the terms of                                      |
|-----------------|------------|--------------------------------------------------------------|
| [jpegli]        | [031a007]  | BSD 3-Clause                                                 |

[031a007]: https://github.com/google/jpegli/commit/031a0077f5799a6041004267fc12b956c1f52a20

[jpegli]: https://github.com/google/jpegli

## zlib

By default, [zlib-ng] is built. This is a zlib replacement with optimizations for
"next generation" systems. You can use the `--without-zlib-ng` argument during the
build when (vanilla-)[zlib] is preferred. For example:

```bash
./build.sh --without-zlib-ng
```

In that case, the following version of zlib is built:

| Dependency      | Version    | Used under the terms of                                      |
|-----------------|------------|--------------------------------------------------------------|
| [zlib]          | 1.3.2      | [zlib License]                                               |

[zlib]: https://github.com/madler/zlib
[zlib License]: https://github.com/madler/zlib/blob/develop/LICENSE

## HEVC-related dependencies

The above variants can optionally be built with [libde265] and [x265] to process
HEIC images. This can be turned on with the `--with-hevc` argument. For example:

```bash
./build.sh --with-hevc
```

These dependencies include HEVC-related logic and are therefore not included in the
prebuilt binaries while it is patent-encumbered.

| Dependency      | Version    | Used under the terms of                                      |
|-----------------|------------|--------------------------------------------------------------|
| [libde265]      | 1.1.1      | LGPLv3                                                       |
| [x265]          | 4.2        | GPLv2                                                        |

[libde265]: https://github.com/strukturag/libde265
[x265]: https://bitbucket.org/multicoreware/x265_git/wiki/Home
